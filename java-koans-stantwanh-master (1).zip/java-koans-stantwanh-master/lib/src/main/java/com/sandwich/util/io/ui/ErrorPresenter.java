package com.sandwich.util.io.ui;

public interface ErrorPresenter {

	void displayError(String error);
	
}
